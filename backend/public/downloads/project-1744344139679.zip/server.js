```json
const express = require("express");
const MongoClient = require("mongodb").MongoClient;
const ObjectId = require("mongodb").ObjectID;
const bodyParser = require("body-parser");
const path = require("path");
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

let db;

MongoClient.connect("mongodb://localhost:27017/NoteApp", (err, client) => {
  if (err) return console.log(err);
  db = client.db("NoteApp");
  app.listen(3000, () => {
    console.log("App listening on port 3000");
  });
});

app.get("/", (req, res) => {
  db.collection("notes").find().toArray((err, result) => {
    if (err) return console.log(err);
    res.render("index.ejs", { notes: result });
  });
});

app.post("/add_note", (req, res) => {
  db.collection("notes").insertOne(req.body, (err, result) => {
    if (err) return console.log(err);
    res.redirect("/");
  });
});

app.get("/edit_note/:id", (req, res) => {
  db.collection("notes").findOne(ObjectId(req.params.id), (err, result) => {
    if (err) return console.log(err);
    res.render("edit_note.ejs", { note: result });
  });
});

app.post("/edit_note/:id", (req, res) => {
  db.collection("notes").findOneAndUpdate(
    ObjectId(req.params.id),
    { $set: req.body },
    (err, result) => {
      if (err) return res.send(err);
      res.redirect("/");
    }
  );
});

app.get("/delete_note/:id", (req, res) => {
  db.collection("notes").findOneAndDelete(
    ObjectId(req.params.id),
    (err, result) => {
      if (err) return res.send(err);
      res.redirect("/");
    }
  );
});
```