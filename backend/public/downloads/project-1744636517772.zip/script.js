```javascript
document.getElementById("add-to-cart").addEventListener("click", function(){
  alert("Item added to cart!");
});
```

Please replace "https://yourlinktoclothingitem.jpg" with your own image URL. This is a skeleton of a product card with an image, product name, product price, and an add to cart button. The JavaScript file just contains a basic function that displays an alert when the 'Add to cart' button is clicked - in a real-world application this would interact either with local storage or an API to add the item to the user's cart.