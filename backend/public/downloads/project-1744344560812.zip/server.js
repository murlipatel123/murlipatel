```javascript
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();

app.use(bodyParser.json());

mongoose.connect(/* your MongoDB connection string */);

const Model = mongoose.model('Model', new mongoose.Schema({ /* your schema here */ }));

// Create
app.post('/data', (req, res) => {
    const newEntry = new Model(req.body);
    newEntry.save()
        .then(() => res.json({ message: 'Created successfully' }))
        .catch((error) => res.status(400).json({ error }));
});

// Read
app.get('/data', (req, res) => {
    Model.find()
        .then((data) => res.json(data))
        .catch((error) => res.status(400).json({ error }));
});

// Update
app.put('/data/:id', (req, res) => {
    Model.findByIdAndUpdate(req.params.id, req.body)
        .then(() => res.json({ message: 'Updated successfully' }))
        .catch((error) => res.status(400).json({ error }));
});

// Delete
app.delete('/data/:id', (req, res) => {
    Model.findByIdAndDelete(req.params.id)
        .then(() => res.json({ message: 'Deleted successfully' }))
        .catch((error) => res.status(400).json({ error }));
});

app.listen(3000);
```