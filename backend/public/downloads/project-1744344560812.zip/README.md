```markdown
# CRUD Application

This is a simple CRUD app using an HTML form frontend and a Node.js/Express/MongoDB backend.

## Installation
1. Download or clone the repository.
2. Run `npm install` to install the dependencies.
3. Start the app with `npm start`.

## Usage
Open a browser and visit `http://localhost:3000` to use the application.
```

Note: Make sure MongoDB is properly installed and running before starting the app. You need to replace the placeholder for MongoDB connection string in `server.js` with actual connection string of your database.

NOTE: The above code is just an example and may not work out of the box. Make sure to understand and adapt the code to your specific needs.