```markdown
# Simple CRUD App

This is a simple CRUD application using Node.js, Express, and MongoDB

## Setup and Running

* Install dependencies: `npm install`.
* Run the server: `npm start`.
* Open a web browser to `http://localhost:3000` to see the application running.
```

Due to the character limitations here, it's not feasible to provide all the detailed validation, error handling, and front-end JavaScript code for communicating with the server. The injected JavaScript within index.html needs to be fleshed out to perform the actual CRUD operations and update the task list, or alternatively, it can be replaced by Vue.js or another frontend framework for better structure and maintainability.