```javascript
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

mongoose.connect('mongodb://localhost/crud-app', {
    useUnifiedTopology: true,
    useNewUrlParser: true
});

const Task = mongoose.model('Task', { text: String });

const app = express();
app.use(bodyParser.json());

// API endpoints
app.post('/tasks', async (req, res) => {
    const task = new Task(req.body);
    await task.save();
    res.send(task);
});

app.get('/tasks', async (req, res) => {
    const tasks = await Task.find();
    res.send(tasks);
});

app.put('/tasks/:id', async (req, res) => {
    await Task.findByIdAndUpdate(req.params.id, req.body);
    res.send({ message: 'Task updated' });
});

app.delete('/tasks/:id', async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    res.send({ message: 'Task deleted' });
});

app.listen(3000, () => console.log('Server running at http://localhost:3000'));
```