```js
// Not implement for a short demo
```