```js
// Import required modules
const express = require('express');
const fs = require('fs');

// Create an Express application
const app = express();

// Use the JSON middleware
app.use(express.json());

// Define CRUD operations
app.get('/api/users', (req, res) => {
  const data = fs.readFileSync('data/crud_data.json');
  res.send(JSON.parse(data));
});

// Start the server
app.listen(3000, () => console.log('Server is running...'));
```