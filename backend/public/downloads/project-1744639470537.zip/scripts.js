```javascript
// Basic script to display "Under Construction" for now
document.getElementById('products-list').innerText = 'Under Construction';
```

This is just a very basic and non-functional stub for an e-commerce website. A real e-commerce website would require a back-end language like Node.js or Python to connect to a server, a database system like MySQL or MongoDB to store product and user data, an authentication system to handle user login, session, and authorization, etc. This would also need to follow security protocols to keep the users' data safe.