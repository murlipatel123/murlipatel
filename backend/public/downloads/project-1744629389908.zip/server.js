```javascript
const express = require('express');
const app = express();
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/home.html');
});

MongoClient.connect('mongodb://your-url', function(err, client) {
    if(err) {
        console.log('Error occurred while connecting to MongoDB Atlas...\n', err);
    }
    console.log('Connected...');
    const collection = client.db("test").collection("devices");
    // perform actions on the collection object
    client.close();
});

app.listen(3000, function() {
    console.log('listening on 3000');
});
```

Given the complexity of your request, creating an entire dating website from scratch is beyond the scope of this platform. There are many more HTML, CSS, JavaScript, and Node.js files required plus the MongoDB integration, user authentication, and many more features. Consider hiring a team of web developers or a web development agency to handle this project. They would be able to create a complete, production-ready dating website according to your requirements.