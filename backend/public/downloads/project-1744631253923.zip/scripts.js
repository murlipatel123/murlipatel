```JavaScript
document.addEventListener('DOMContentLoaded', function () {
   var products = [
      { name: 'Product 1', price: '$100' },
      { name: 'Product 2', price: '$200' }
   ];

   var productsSection = document.getElementById('products');

   products.forEach(function (product) {
      var productCard = document.createElement('div');
      productCard.className = 'product-card';

      var productName = document.createElement('h2');
      productName.innerText = product.name;
      productCard.appendChild(productName);

      var productPrice = document.createElement('p');
      productPrice.innerText = product.price;
      productCard.appendChild(productPrice);

      productsSection.appendChild(productCard);
   });
});
```

The above files represent a simple e-commerce homepage. It has two products, each with a name and a price. This is a very minimal example and a real e-commerce website would need functionality for adding to cart, user authentication, backend database, and much more which can't be illustrated within this simple example. You can use this code as a starting point to expand from.