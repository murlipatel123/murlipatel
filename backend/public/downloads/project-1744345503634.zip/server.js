```javascript
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/test', {useNewUrlParser: true, useUnifiedTopology: true});

const app = express();

app.use(bodyParser.json());

require('./model/CRUD'); // including the required model 

const CRUD = mongoose.model('crudcollec'); // getting the model from the Schema  

app.post('/data',(req, res)=>{
    new CRUD({
        data1: req.body.data1,
        data2: req.body.data2
    }).save().then((data)=>{
        console.log(data)
        res.redirect('/');
    })
});

app.listen(5000, () => {
    console.log("Server is running on port 5000");
});
```