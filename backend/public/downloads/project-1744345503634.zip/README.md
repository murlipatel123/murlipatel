```
# CRUD Application

This is a simple CRUD (Create, Read, Update, Delete) application built with MongoDB, Express.js, Node.js, and vanilla JavaScript.

## Running Locally

Make sure you have Node.js and MongoDB installed.

```
git clone https://github.com/username/thisrepository.git
cd repository
npm install
npm start
```

Then open http://localhost:5000 in your browser.
```