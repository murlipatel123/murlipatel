```javascript
window.onload = function() {
  var products = [
    { id: 1, title: 'Product 1', price: '$100' },
    { id: 2, title: 'Product 2', price: '$200' },
    { id: 3, title: 'Product 3', price: '$300' },
    // Add more products as needed
  ];

  var productsContainer = document.getElementById('products');

  for (var i = 0; i < products.length; i++) {
    var productDiv = document.createElement('div');
    productDiv.classList.add('product');

    var productTitle = document.createElement('div');
    productTitle.classList.add('title');
    productTitle.innerText = products[i].title;

    var productPrice = document.createElement('div');
    productPrice.classList.add('price');
    productPrice.innerText = products[i].price;

    productDiv.appendChild(productTitle);
    productDiv.appendChild(productPrice);

    productsContainer.appendChild(productDiv);
  }
};
```

This is a very basic framework for an e-commerce application. It doesn't include more advanced aspects such as shopping cart functionality, user login, or interacting with an API to fetch products. But it should give you a starting point to build from.
Here, HTML structures the webpage, CSS adds styles to make it look better, and JavaScript is used to insert products into the page dynamically.