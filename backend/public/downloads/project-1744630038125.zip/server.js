```javascript
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
const todoSchema = new mongoose.Schema({
  text: { type: String, required: true },
});
const Todo = mongoose.model('Todo', todoSchema);

app.post('/api/todos', async (req, res) => {
  const todo = new Todo({ text: req.body.text });
  try {
    await todo.save();
    res.send(todo);
  } catch (error) {
    res.status(500).send(error);
  }
});

app.get('/api/todos', async (req, res) => {
  try {
    const todos = await Todo.find();
    res.send(todos);
  } catch (error) {
    res.status(500).send(error);
  }
});

app.put('/api/todos/:id', async (req, res) => {
  try {
    const todo = await Todo.findOneAndUpdate(
      { _id: req.params.id },
      { text: req.body.text },
      { new: true }
    );
    res.send(todo);
  } catch (error) {
    res.status(500).send(error);
  }
});

app.delete('/api/todos/:id', async (req, res) => {
  try {
    await Todo.findByIdAndDelete(req.params.id);
    res.send({ message: 'Todo deleted' });
  } catch (error) {
    res.status(500).send(error);
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT);
```

3. Provide a `.env.example` file for setting up environment variables:

//