```js
document.addEventListener('DOMContentLoaded', (event) => {
    console.log("Page loaded and ready.");
    // Sample code to listen to a click event on 'Add to Cart' button for the first product.
    document.querySelector('#products .product button').addEventListener('click', function() {
        alert("Adding product to cart!");
    });
});
```

This is a basic structure that is fully compliable with modern and responsive design principles. To continue, each page (product list, product detail, shopping cart) should be separated into its own HTML file, with consistent header & footer. Data should be dynamically loaded, either from hardcoded data or an API.

For a production website, consider using a modern frontend JavaScript framework/library like React, Vue, or Angular, and a backend such as Node.js/Express. Use a state management library/tool (such as Redux) for maintaining global state like user info and shopping cart items. Also, consider implementing dark mode using CSS variables, and animations using CSS transitions/transforms or a library such as Framer Motion or React Spring.