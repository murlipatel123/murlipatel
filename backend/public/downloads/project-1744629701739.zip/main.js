```
document.addEventListener('DOMContentLoaded', function() {
    let productData = [
        {id: 1, name: 'Product 1', price: 100},
        {id: 2, name: 'Product 2', price: 200},
        {id: 3, name: 'Product 3', price: 300},
        // More products here...
    ];
    let productList = document.getElementById('product-list');
    for (let product of productData) {
        let div = document.createElement('div');
        div.className = 'product';
        div.innerHTML = `
            <h2>${product.name}</h2>
            <p>Price: $${product.price}</p>
            <button>Add to Cart</button>
        `;
        productList.appendChild(div);
    }
});
```

Again, these give you a starting point for a shopping website but it lacks many essential features like handling the adding of items to a shopping cart, the cart page, user authentication, server side processing, database storage and much more. For a complete solution, consider hiring a professional developer or web development agency.