```javascript
const buttons = document.querySelectorAll('button');

buttons.forEach((button) => {
    button.addEventListener('click', () => {
        alert('Product added to cart!')
    });
});
```
Remember, we are just creating a simple static page here. For a full-featured, real-world shopping site, you would need to use more advanced technologies like frontend and backend frameworks (React, Angular, Vue for front-end; Node.js, Django, Ruby on Rails etc for back-end), databases (mySQL, MongoDB, PostgreSQL etc.), and possibly cloud storage for product images (AWS S3, Google Cloud Storage etc.), and tools for user authentication and secure payment handling.
Lastly, the website UI can be made rich using bootstrap or any front-end libraries. Also, It's critical to ensure that your shopping website is responsive, supports all devices, and properly handles user input and server responses. Plus, you should also consider SEO parameters for the web app.