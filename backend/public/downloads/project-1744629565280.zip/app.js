```js
window.onload = () => {
    const productList = document.getElementById('product-list');
    const products = [
        { id: 1, name: 'Product 1', image: 'path-to-image' },
        { id: 2, name: 'Product 2', image: 'path-to-image' },
        { id: 3, name: 'Product 3', image: 'path-to-image' },
    ];

    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';

        const productImage = document.createElement('img');
        productImage.src = product.image;

        const productName = document.createElement('h2');
        productName.textContent = product.name;

        productCard.appendChild(productImage);
        productCard.appendChild(productName);

        productList.appendChild(productCard);
    });
};
```

This is a static example for a simple products listing page. It's oversimplified version and in reality, we need things like a more complex product model, product detail page, cart functionality, user authentication, etc. Depending on requirements, this solution might not be ideal and a more complex setup using a library or a framework like React, Angular, or Vue might be required. However, it demonstrates the basic concept of a shopping website.