```JavaScript
$(document).ready(function() {
  // Handle register and login clicks
  $('#register').on('click', function() {
    window.location.href = '/register.html';
  });

  $('#login').on('click', function() {
    window.location.href = '/login.html';
  });
});
```