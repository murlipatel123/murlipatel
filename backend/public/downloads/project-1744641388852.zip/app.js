document.getElementById('messageForm').addEventListener('submit', function(e){
    e.preventDefault();
    sendMessage();
});

const sendMessage = () => {
  let messageBox = document.getElementById('m');
  let text = messageBox.value;
  if(text.trim() != ''){
    let messages = document.getElementById('messages');
    let newMessage = document.createElement('li');
    newMessage.textContent = text;
    messages.appendChild(newMessage);
    messageBox.value = '';
    messages.scrollTop = messages.scrollHeight;
  }
}
```
This will add the functionality to our form so we can update the chat box every time we send a message. Please note, this is a much-simplified version of a chat application and does not support real-time communication with another user. 

Features like direct messaging, real-time message sending/receiving, message read receipts, group chats, file sharing, etc will need a real backend that integrates with a database for storing messages and handling user authentication, likely utilizing technologies like Node.js, Express, MongoDB and socket.io for real-time communication. Best practices for large scale applications would also dictate separate files for handling server routes and database schemas. You would also likely need features like Google/Facebook/GitHub OAuth for user authentication.