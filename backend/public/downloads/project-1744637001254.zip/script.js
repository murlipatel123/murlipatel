```javascript
document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let message = document.getElementById('message').value;
    
    alert('Thank you ' + name + '. Your message has been submitted.');
});
```
This is a very basic contact form. When the user clicks submit, a Javascript event listener prevents the form from actually submitting (which would refresh the page), and instead it displays an alert box. This code does not actually save or send the user input anywhere. In a real-world scenario, you would probably want to have the form data sent to a server or added to a database.