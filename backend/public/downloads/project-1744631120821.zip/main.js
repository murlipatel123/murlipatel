```javascript
document.addEventListener('DOMContentLoaded', function(){
    loadProducts();
});

function loadProducts() {
    const products = [
        {name: 'Product 1', price: '$100'},
        {name: 'Product 2', price: '$200'},
        {name: 'Product 3', price: '$300'},
        // More products here...
    ];

    const productsContainer = document.getElementById('products');

    products.forEach(product => {
        const prodElem = document.createElement('div');
        prodElem.classList.add('product');
        prodElem.innerHTML = `
            <h2>${product.name}</h2>
            <p>${product.price}</p>
            <button>Add to Cart</button>
        `;
        productsContainer.appendChild(prodElem);
    });
}
```

This is as simple and basic as it gets. You would need to expand quite a lot for real world usage, including pages for each product, a shopping cart, user authentication process (login/register/reset password), reviews, ratings, etc. For complex applications like this, you would break out each feature into separate components using a front-end framework such as React, Angular, Vue.js, and would also bring in back-end technology for user authentication, database communication, etc.