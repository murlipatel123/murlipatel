```javascript
document.addEventListener('DOMContentLoaded', function() {
    const products = [
        {id: 1, name: 'Product 1', price: '10.00'},
        {id: 2, name: 'Product 2', price: '20.00'},
        {id: 3, name: 'Product 3', price: '30.00'},
    ];

    const productsSection = document.querySelector('#products');
    products.forEach(product => {
        const productElement = document.createElement('div');
        productElement.innerHTML = `
            <h2>${product.name}</h2>
            <p>Price: $${product.price}</p>
            <button>Add to Cart</button>
        `;
        productsSection.appendChild(productElement);
    });
});
```

This is a simple static representation, and a real-world e-commerce app would be much more complex. It would require a database to manage inventory, user-friendly interfaces for viewing and purchasing items, secure user authentication, and a robust back-end system to handle transactions and payments. The code in this particular example simply lists out three products on a page, and doesn't include functionality for a shopping cart, product page, or user account system. It should be used as a very basic starting point or tutorial introduction to web development.