```javascript
document.getElementById("booking-form").addEventListener("submit", function(event){
  event.preventDefault();

  let form = document.getElementById('booking-form');
  let name = document.getElementById('name').value;
  let email = document.getElementById('email').value;
  let date = document.getElementById('date').value;
  let destination = document.getElementById('destination').value;

  console.log(`Name: ${name}, Email: ${email}, Date: ${date}, Destination: ${destination}`);
  
  // Here, you can implement the logic to save the data or send it to a server.

  form.reset();
});
```
Above, the JavaScript file has a listener for the submit event of the form which prevents the default submit event and then gathers the form values to then do something with them. We are just logging the values to the console and resetting the form. You can modify this section as per your needs.