```javascript
function openSignup() {
    let signupModal = document.getElementById('signup-modal');
    signupModal.style.display = 'block';
}

function openLogin() {
    let loginModal = document.getElementById('login-modal');
    loginModal.style.display = 'block';
}
```

Please note that while this is a simplistic view of your website, a real version of this type of website would be quite complex and involve a lot more files. For user registration, logins, messaging, and profile info, you would need a server-side setup using something like Node.js, PHP etc. and some type of database (like MySQL, MongoDB etc). Furthermore, you would also need proper security measures in place to protect user data, such as hashing passwords. A professional web developer or a team would typically be needed for such a project. On that note, CSS frameworks like Bootstrap or Tailwind CSS can be used to quickly create professional and responsive designs. Additionally, you can also use JavaScript libraries or frameworks, such as React.js or Vue.js, to help structure your front end code.