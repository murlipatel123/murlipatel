```javascript
document.addEventListener('DOMContentLoaded', (event) => {
    let products = [
        { name: 'Product 1', description: 'Description for product 1', price: '$100' },
        { name: 'Product 2', description: 'Description for product 2', price: '$200' },
        // Add more products as needed
    ];

    let productsContainer = document.getElementById('products');

    products.forEach((product) => {
        let productElement = document.createElement('div');
        productElement.className = 'product';

        let productName = document.createElement('h3');
        productName.textContent = product.name;
        productElement.appendChild(productName);

        let productDescription = document.createElement('p');
        productDescription.textContent = product.description;
        productElement.appendChild(productDescription);

        let productPrice = document.createElement('p');
        productPrice.textContent = product.price;
        productElement.appendChild(productPrice);

        productsContainer.appendChild(productElement);
    });
});
```

Please ensure to have these three files in the same directory to have them run and interact correctly. The app simply displays a list of static products, it doesn't yet allow users to add items to a cart, checkout, or any other e-commerce features. Those would require a server-side language and a database to store products, orders, and user information. This example is just for demonstration purposes.