```javascript
document.getElementById('sign-up').addEventListener('click', function() {
    // Implement sign up functionality here
    console.log('Sign Up button clicked');
});
document.getElementById('log-in').addEventListener('click', function() {
    // Implement log in functionality here
    console.log('Log In button clicked');
});
```

This skeleton contains the homepage with a Welcome banner, tagline, and call-to-action buttons for sign-up and login. You would need to expand this into separate HTML pages for user registration, user profiles, browsing profiles and a user dashboard. Each of these pages would require their own JavaScript and CSS functionality.

Furthermore, real-life implementation of registering users, logging in, and storing sensitive data such as passwords is complex and must be done securely. This usually involves hashing of passwords, authentication, sessions and it goes well beyond these examples. 

To implement this, I strongly recommend familiarizing yourself thoroughly with Node.js, Express.js, Passport.js, MongoDB/Mongoose and probably a tutorial on how to create a secure login system with these technologies. Chatting feature would also require real-time bi-directional event-based communication, which is usually done with WebSockets with Socket.IO.